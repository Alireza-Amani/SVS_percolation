#define f77name(a) a##_
#define f77_name(a) a##_
#define Little_Endian
#define PTR_AS_INT int
#define INT_32 int
#define INT_64 long long
#define tell(fdesc) lseek(fdesc,0,1)
#define FORTRAN_loc_delta           4
#define wordint INT_32
#define ftnword INT_32
#define ftnfloat float
#define wordfloat float
#define bytesperword 4
#define D77MULT            4
#define F2Cl int
